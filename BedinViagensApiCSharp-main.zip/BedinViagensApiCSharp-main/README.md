# Bedin Viagens (API, C# e React)
Usando tecnologias web DOT NET, desenvolvi uma aplicação web API em C# para consumir os dados da agencia de viagens (consulta, criação, edição e exclusão da base de dados).
Criei também uma versão mobile para consultar clientes e destinos da Bedin Viagens. 

## Vídeo de demonstração:

https://github.com/erika-bedin/BedinViagensApiCSharp/assets/127342699/7c9bd635-0cc8-4894-9668-12ddde1e6ee9


## Banco de dados 
Ajuste da base de dados para relatórios das APIs e disponibilização de acesso aos dados consumidos pelas APIs.


## Back-end 
Desenvolvi as APIs para manipulação de dados em C#.
 

## Front-end 
Criei uma interface mobile usando React Native para consultas usando API em C#. 
