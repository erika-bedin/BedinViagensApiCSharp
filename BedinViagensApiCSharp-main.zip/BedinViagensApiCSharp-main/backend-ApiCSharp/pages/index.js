const ClientList2 = () => {
  return(
    <div>
      <p style={{textAlign:'center', marquee:''}}>Bem Vindx ao Bedin Viagens</p>
    </div>
  )
};

export default ClientList2;
