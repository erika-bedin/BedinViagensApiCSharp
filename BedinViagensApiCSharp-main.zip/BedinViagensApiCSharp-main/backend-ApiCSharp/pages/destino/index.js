import "bootstrap/dist/css/bootstrap.css";
import { useEffect, useState } from "react";
import axios from "axios";
import style from "../../styles/Home.module.css";
import Link from "next/link"; // Importe o Link para criar links de navegação

const Home = () => {
  const [destinos, setDestinos] = useState([]);

  useEffect(() => {
    // Faça uma chamada GET para a API Spring Boot
    axios
      .get("https://localhost:7203/api/Destinos")
      .then((response) => {
        setDestinos(response.data);
      })
      .catch((error) => {
        console.error("Erro ao buscar a lista de destinos:", error);
      });
  }, []);

  return (
    <div>
      <h1 className={style.h1}>Lista de Destinos</h1>
      
      <table className="table container tabela">
        <thead>
          <tr>
            <th>Id</th>
            <th>Destino</th>
            <th>Descrição</th>
            <th>Hotel</th>
            <th>Preço</th>            
            <th>ImagemUrl</th>
          </tr>
        </thead>
        {destinos.map((element) => (
          <tbody key={element.id}>
            <tr className={style.tabela}>
              <td>{element.destinoId}</td>
              <td>{element.local}</td>
              <td>{element.descricao}</td>
              <td>{element.hotel}</td>
              <td>{element.preco}</td>
              <td>{element.imagemUrl}</td>
            </tr>
          </tbody>
        ))}
      </table>
    </div>
  );
};

export default Home;
